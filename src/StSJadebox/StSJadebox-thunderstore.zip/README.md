### StS Jadebox(es)

funny jadebox with sts relics. Maybe I'll add more

---------
#### Change log

`0.5.1` gained StS exhibits will no longer appear in a shop.