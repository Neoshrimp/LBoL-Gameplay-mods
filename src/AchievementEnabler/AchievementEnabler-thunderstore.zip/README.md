#### Achievement Enabler

Enables achievements with Jadeboxes toggled.

*Updated for LBoL version 1.4*

---
