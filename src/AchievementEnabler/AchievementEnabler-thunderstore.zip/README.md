#### Achievement Enabler

Enables achievements with Jadeboxes toggled.


---
*Change log*

`1.1.1` Update for LBoL 1.7.0

`1.1.0` Update for LBoL 1.6.1 beta.

`1.0.1` Update for LBoL 1.6.0 beta. **Not compatible with previous versions.**

