#### Always get starting bonus

[**Download**](https://github.com/Neoshrimp/LBoL-Gameplay-mods/raw/master/src/HelpMeEirin/HelpMeEirin.dll)

that's all
